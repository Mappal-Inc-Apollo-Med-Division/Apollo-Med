// Inspired by Vitaly Silkin's Dribbble shot:
// https://dribbble.com/shots/3907093-Escalade-loader